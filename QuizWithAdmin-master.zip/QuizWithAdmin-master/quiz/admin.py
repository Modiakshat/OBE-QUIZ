from django.contrib import admin
from .models import Answer,Testappear,question,StudentReport,Quiz123,Testcategory,registerform,Record,Option,AdminForm
# Register your models here.
admin.site.register([Answer,question,Testappear,Quiz123,Testcategory,registerform,Record,Option,AdminForm,StudentReport])










